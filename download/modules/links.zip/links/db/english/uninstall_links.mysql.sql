DROP TABLE IF EXISTS `phpboost_links`;
