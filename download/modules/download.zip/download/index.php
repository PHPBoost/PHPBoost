<?php header('location: ./download.php'); ?>
