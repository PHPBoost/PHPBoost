DROP TABLE IF EXISTS `phpboost_web_cat`;
DROP TABLE IF EXISTS `phpboost_web`;
