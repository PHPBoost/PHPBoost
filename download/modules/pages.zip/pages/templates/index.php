<?php
	header('Location: pages.php');
	exit;
?>
