DROP TABLE IF EXISTS `phpboost_pages`;
DROP TABLE IF EXISTS `phpboost_pages_cats`;
