INSERT INTO `phpboost_configs` (`name`, `value`) VALUES ('online', 'a:2:{s:16:"online_displayed";i:4;s:20:"display_order_online";s:28:"s.level, s.session_time DESC";}');
INSERT INTO `phpboost_modules_mini` (`name`, `code`, `contents`, `side`, `secure`, `activ`, `added`) VALUES ('online', 'include_once(''../online/online_mini.php'');', '', 1, -1, 1, 0);
