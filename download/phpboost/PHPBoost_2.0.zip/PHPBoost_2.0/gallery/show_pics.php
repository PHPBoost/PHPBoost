<?php
/*##################################################
 *                               show_pics.php
 *                            -------------------
 *   begin                : August 12, 2005
 *   copyright          : (C) 2005 Viarre R�gis
 *   email                : crowkait@phpboost.com
 *
 *  
 *
###################################################
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
###################################################*/

include_once('../includes/begin.php'); 
include_once('../gallery/lang/' . $CONFIG['lang'] . '/gallery_' . $CONFIG['lang'] . '.php'); //Chargement de la langue du module.
$speed_bar = '';
define('TITLE', $LANG['title_gallery']);
include_once('../includes/header_no_display.php');
include_once('../gallery/gallery_auth.php');

$g_idpics = !empty($_GET['id']) ? numeric($_GET['id']) : 0;
$g_idcat = !empty($_GET['cat']) ? numeric($_GET['cat']) : 0;

if( !$groups->check_auth($SECURE_MODULE['gallery'], ACCESS_MODULE) )
{
	$errorh->error_handler('e_auth', E_USER_REDIRECT); 
	exit;
}
	
if( !empty($g_idpics) )
{
	if( !empty($g_idcat) )
	{
		if( !isset($CAT_GALLERY[$g_idcat]) || $CAT_GALLERY[$g_idcat]['aprob'] == 0 ) 
		{	
			header('location: ' . HOST . DIR . '/gallery/gallery.php?error=unexist_cat');
			exit;
		}
	}
	else //Racine.
	{
		$CAT_GALLERY[0]['auth'] = $CONFIG_GALLERY['auth_root'];
		$CAT_GALLERY[0]['aprob'] = 1;
	}
	//Niveau d'autorisation de la cat�gorie
	if( !$groups->check_auth($CAT_GALLERY[$g_idcat]['auth'], READ_CAT_GALLERY) )
	{
		$errorh->error_handler('e_auth', E_USER_REDIRECT); 
		exit;
	}
	
	//Mise � jour du nombre de vues.
	$sql->query_inject("UPDATE LOW_PRIORITY ".PREFIX."gallery SET views = views + 1 WHERE idcat = '" . $g_idcat . "' AND id = '" . $g_idpics . "'", __LINE__, __FILE__);
	
	$clause_admin = $session->data['level'] == 2 ? '' : ' AND aprob = 1';
	$path = $sql->query("SELECT path FROM ".PREFIX."gallery WHERE idcat = '" . $g_idcat . "' AND id = '" . $g_idpics . "'" . $clause_admin, __LINE__, __FILE__);
	if( empty($path) )
	{
		$errorh->error_handler('e_auth', E_USER_REDIRECT); 
		exit;
	}

	include_once('../gallery/gallery.class.php');
	$gallery = new gallery($sql->req);
		
	list($width_s, $height_s, $weight_s, $ext) = $gallery->arg_pics('pics/' . $path);
	$gallery->send_header($ext); //Header image.
	if( !empty($gallery->error) )
		die($gallery->error);
	$gallery->incrust_pics('pics/' . $path); // => logo.
}
else
{
	die($LANG['no_random_img']); //Echec param�tres images incorrects.
}

include_once('../includes/footer_no_display.php');

?>