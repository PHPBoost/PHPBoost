DROP TABLE IF EXISTS `phpboost_gallery`;
DROP TABLE IF EXISTS `phpboost_gallery_cats`;
