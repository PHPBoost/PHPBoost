<?php
/*##################################################
 *                               admin_forum_config.php
 *                            -------------------
 *   begin                : October 30, 2005
 *   copyright          : (C) 2005 Viarre R�gis
 *   email                : crowkait@phpboost.com
 *
 * 
 *
###################################################
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
###################################################*/

include_once('../includes/admin_begin.php');
include_once('../forum/lang/' . $CONFIG['lang'] . '/forum_' . $CONFIG['lang'] . '.php'); //Chargement de la langue du module.
define('TITLE', $LANG['administration']);
include_once('../includes/admin_header.php');

$get_id = !empty($_GET['id']) ? numeric($_GET['id']) : '';	
$id_post = !empty($_POST['idc']) ? numeric($_POST['idc']) : '';  
$update_cached = !empty($_GET['upd']) ? true : false;	

//Si c'est confirm� on execute
if( !empty($_POST['valid']) )
{
	$config_forum = array();
	$config_forum['forum_name'] = !empty($_POST['forum_name']) ? stripslashes(securit($_POST['forum_name'])) : $CONFIG['site_name'] . ' forum';  
	$config_forum['pagination_topic'] = !empty($_POST['pagination_topic']) ? numeric($_POST['pagination_topic']) : '20';  
	$config_forum['pagination_msg'] = !empty($_POST['pagination_msg']) ? numeric($_POST['pagination_msg']) : '15';
	$config_forum['view_time'] = !empty($_POST['view_time']) ? (numeric($_POST['view_time']) * 3600 * 24) : (30 * 3600 * 24);
	$config_forum['topic_track'] = !empty($_POST['topic_track']) ? numeric($_POST['topic_track']) : '40';
	$config_forum['edit_mark'] = !empty($_POST['edit_mark']) ? numeric($_POST['edit_mark']) : 0;
	$config_forum['no_left_column'] = !empty($_POST['no_left_column']) ? numeric($_POST['no_left_column']) : 0;
	$config_forum['no_right_column'] = !empty($_POST['no_right_column']) ? numeric($_POST['no_right_column']) : 0;
	$config_forum['activ_display_msg']  = !empty($_POST['activ_display_msg']) ? numeric($_POST['activ_display_msg']) : 0;
	$config_forum['display_msg'] = !empty($_POST['display_msg']) ? stripslashes(securit($_POST['display_msg'])) : '';
	$config_forum['explain_display_msg'] = !empty($_POST['explain_display_msg']) ? stripslashes(securit($_POST['explain_display_msg'])) : '';	
	$config_forum['explain_display_msg_bis'] = !empty($_POST['explain_display_msg_bis']) ? stripslashes(securit($_POST['explain_display_msg_bis'])) : '';
	$config_forum['icon_activ_display_msg'] = !empty($_POST['icon_activ_display_msg']) ? numeric($_POST['icon_activ_display_msg']) : 0;
		
	if( !empty($config_forum['forum_name']) && !empty($config_forum['pagination_topic']) && !empty($config_forum['pagination_msg']) && !empty($config_forum['view_time']) )
	{
		$sql->query_inject("UPDATE ".PREFIX."configs SET value = '" . addslashes(serialize($config_forum)) . "' WHERE name = 'forum'", __LINE__, __FILE__);
			
		###### R�g�n�ration du cache du forum ###### 
		$cache->generate_module_file('forum');
				
		header('location:' . HOST . SCRIPT);	
		exit;
	}
	else
	{
		header('location:' . HOST . DIR . '/forum/admin_forum_config.php?error=incomplete#errorh');
		exit;
	}
}
elseif( $update_cached ) //Mise � jour des donn�es stock�es en cache dans la bdd.
{
	$result = $sql->query_while("SELECT id
	FROM ".PREFIX."forum_cats", __LINE__, __FILE__);
	while($row = $sql->sql_fetch_assoc($result) )
	{	
		$info_cat = $sql->query_array("forum_topics", "COUNT(*) as nbr_topic", "SUM(nbr_msg) as nbr_msg", "WHERE idcat = '" . $row['id'] . "'", __LINE__, __FILE__);
		$sql->query_inject("UPDATE ".PREFIX."forum_cats SET nbr_topic = '" . $info_cat['nbr_topic'] . "', nbr_msg = '" . $info_cat['nbr_msg'] . "' WHERE id = '" . $row['id'] . "'", __LINE__, __FILE__);	
	}
	$sql->close($result);
	
	###### R�g�n�ration du cache du forum ###### 
	$cache->generate_module_file('forum');
	
	header('location:' . HOST . SCRIPT);	
	exit;
}
else	
{	
	$template->set_filenames(array(
		'admin_forum_config' => '../templates/' . $CONFIG['theme'] . '/forum/admin_forum_config.tpl'
	));

	$cache->load_file('forum');
	
	//Gestion erreur.
	$get_error = !empty($_GET['error']) ? securit($_GET['error']) : '';
	if( $get_error == 'incomplete' )
		$errorh->error_handler($LANG['e_incomplete'], E_USER_NOTICE);
	
	$CONFIG_FORUM['edit_mark'] = isset($CONFIG_FORUM['edit_mark']) ? $CONFIG_FORUM['edit_mark'] : 0;
	$CONFIG_FORUM['no_left_column'] = isset($CONFIG_FORUM['no_left_column']) ? $CONFIG_FORUM['no_left_column'] : 0;
	$CONFIG_FORUM['no_right_column'] = isset($CONFIG_FORUM['no_right_column']) ? $CONFIG_FORUM['no_right_column'] : 0;
	$CONFIG_FORUM['activ_display_msg'] = isset($CONFIG_FORUM['activ_display_msg']) ? $CONFIG_FORUM['activ_display_msg'] : 0;
	$CONFIG_FORUM['icon_display_msg'] = isset($CONFIG_FORUM['icon_display_msg']) ? $CONFIG_FORUM['icon_display_msg'] : 1;

	$template->assign_vars(array(
		'THEME' => $CONFIG['theme'],
		'MODULE_DATA_PATH' => $template->module_data_path('forum'),
		'FORUM_NAME' => !empty($CONFIG_FORUM['forum_name']) ? $CONFIG_FORUM['forum_name'] : '',
		'PAGINATION_TOPIC' => !empty($CONFIG_FORUM['pagination_topic']) ? $CONFIG_FORUM['pagination_topic'] : '20',
		'PAGINATION_MSG' => !empty($CONFIG_FORUM['pagination_msg']) ? $CONFIG_FORUM['pagination_msg'] : '15',
		'VIEW_TIME' => !empty($CONFIG_FORUM['view_time']) ? $CONFIG_FORUM['view_time']/(3600*24) : '30',
		'TOPIC_TRACK_MAX' => !empty($CONFIG_FORUM['topic_track']) ? $CONFIG_FORUM['topic_track'] : '40',	
		'EDIT_MARK_ENABLED' => ($CONFIG_FORUM['edit_mark'] == 1) ? 'checked="checked"' : '',
		'EDIT_MARK_DISABLED' => ($CONFIG_FORUM['edit_mark'] == 0) ? 'checked="checked"' : '',
		'NO_LEFT_COLUMN_ENABLED' => ($CONFIG_FORUM['no_left_column'] == 1) ? 'checked="checked"' : '',
		'NO_LEFT_COLUMN_DISABLED' => ($CONFIG_FORUM['no_left_column'] == 0) ? 'checked="checked"' : '',
		'NO_RIGHT_COLUMN_ENABLED' => ($CONFIG_FORUM['no_right_column'] == 1) ? 'checked="checked"' : '',
		'NO_RIGHT_COLUMN_DISABLED' => ($CONFIG_FORUM['no_right_column'] == 0) ? 'checked="checked"' : '',
		'DISPLAY_MSG_ENABLED' => ($CONFIG_FORUM['activ_display_msg'] == 1) ? 'checked="checked"' : '',
		'DISPLAY_MSG_DISABLED' => ($CONFIG_FORUM['activ_display_msg'] == 0) ? 'checked="checked"' : '',
		'DISPLAY_MSG' => !empty($CONFIG_FORUM['display_msg']) ? $CONFIG_FORUM['display_msg'] : '',
		'EXPLAIN_DISPLAY_MSG' => !empty($CONFIG_FORUM['explain_display_msg']) ? $CONFIG_FORUM['explain_display_msg'] : '',
		'EXPLAIN_DISPLAY_MSG_BIS' => !empty($CONFIG_FORUM['explain_display_msg_bis']) ? $CONFIG_FORUM['explain_display_msg_bis'] : '',
		'ICON_DISPLAY_MSG_ENABLED' => ($CONFIG_FORUM['icon_activ_display_msg'] == 1) ? 'checked="checked"' : '',
		'ICON_DISPLAY_MSG_DISABLED' => ($CONFIG_FORUM['icon_activ_display_msg'] == 0) ? 'checked="checked"' : '',
		'L_REQUIRE_NAME' => $LANG['require_name'],
		'L_REQUIRE_TOPIC_P' => $LANG['require_topic_p'],
		'L_REQUIRE_NBR_MSG_P' => $LANG['require_nbr_msg_p'],
		'L_REQUIRE_TIME_NEW_MSG' => $LANG['require_time_new_msg'],
		'L_REQUIRE_TOPIC_TRACK_MAX' => $LANG['require_topic_track_max'],
		'L_FORUM_MANAGEMENT' => $LANG['forum_management'],
		'L_CAT_MANAGEMENT' => $LANG['cat_management'],
		'L_ADD_CAT' => $LANG['cat_add'],
		'L_FORUM_CONFIG' => $LANG['forum_config'],
		'L_FORUM_GROUPS' => $LANG['forum_groups_config'],
		'L_FORUM_NAME' => $LANG['forum_name'],
		'L_NBR_TOPIC_P' => $LANG['nbr_topic_p'],
		'L_NBR_TOPIC_P_EXPLAIN' => $LANG['nbr_topic_p_explain'],
		'L_NBR_MSG_P' => $LANG['nbr_msg_p'],
		'L_NBR_MSG_P_EXPLAIN' => $LANG['nbr_msg_p_explain'],
		'L_TIME_NEW_MSG' => $LANG['time_new_msg'],
		'L_TIME_NEW_MSG_EXPLAIN' => $LANG['time_new_msg_explain'],
		'L_TOPIC_TRACK_MAX' => $LANG['topic_track_max'],
		'L_TOPIC_TRACK_MAX_EXPLAIN' => $LANG['topic_track_max_explain'],
		'L_EDIT_MARK' => $LANG['edit_mark'],
		'L_NO_LEFT_COLUMN' => $LANG['no_left_column'],
		'L_NO_RIGHT_COLUMN' => $LANG['no_right_column'],
		'L_ACTIV_DISPLAY_MSG' => $LANG['activ_display_msg'],
		'L_DISPLAY_MSG' => $LANG['display_msg'],
		'L_EXPLAIN_DISPLAY_MSG' => $LANG['explain_display_msg'],
		'L_EXPLAIN_DISPLAY_MSG_EXPLAIN' => $LANG['explain_display_msg_explain'],
		'L_EXPLAIN_DISPLAY_MSG_BIS' => $LANG['explain_display_msg'],		
		'L_EXPLAIN_DISPLAY_MSG_BIS_EXPLAIN' => $LANG['explain_display_msg_bis_explain'],		
		'L_ICON_DISPLAY_MSG' => $LANG['icon_display_msg'],
		'L_ACTIV' => $LANG['activ'],
		'L_UNACTIVE' => $LANG['unactiv'],
		'L_DAYS' => $LANG['day_s'],
		'L_YES' => $LANG['yes'],
		'L_NO' => $LANG['no'],
		'L_DELETE' => $LANG['delete'],
		'L_UPDATE' => $LANG['update'],
		'L_RESET' => $LANG['reset'],
		'L_UPDATE_DATA_CACHED' => $LANG['update_data_cached']
	));

	$template->pparse('admin_forum_config');
}

include_once('../includes/admin_footer.php');

?>