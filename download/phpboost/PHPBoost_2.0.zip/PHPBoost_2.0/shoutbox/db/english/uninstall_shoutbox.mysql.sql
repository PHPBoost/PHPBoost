DROP TABLE IF EXISTS `phpboost_shoutbox`;
