DROP TABLE IF EXISTS `phpboost_poll`;
DROP TABLE IF EXISTS `phpboost_poll_ip`;
