DROP TABLE IF EXISTS `phpboost_news`;
DROP TABLE IF EXISTS `phpboost_news_cat`;
