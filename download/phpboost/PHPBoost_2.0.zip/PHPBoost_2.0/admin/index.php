<?php
	header('location: admin.php');
	exit;
?>
