<?php
/*##################################################
 *                               admin_terms.php
 *                            -------------------
 *   begin                : Februar 06 2007
 *   copyright          : (C) 2007 Viarre R�gis
 *   email                : crowkait@phpboost.com
 *
 *
###################################################
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
###################################################*/

include_once('../includes/admin_begin.php');
define('TITLE', $LANG['administration']);
include_once('../includes/admin_header.php');

$cache->load_file('member');

if( !empty($_POST['msg_register']) ) //Message � l'inscription.
{
	$config_member['activ_register'] = isset($CONFIG_MEMBER['activ_register']) ? numeric($CONFIG_MEMBER['activ_register']) : 0;
	$config_member['activ_mbr'] = isset($CONFIG_MEMBER['activ_mbr']) ? numeric($CONFIG_MEMBER['activ_mbr']) : 0; //d�sactiv� par defaut. 
	$config_member['verif_code'] = isset($CONFIG_MEMBER['verif_code']) ? numeric($CONFIG_MEMBER['verif_code']) : 0; //d�sactiv� par defaut. 
	$config_member['delay_unactiv_max'] = isset($CONFIG_MEMBER['delay_unactiv_max']) ? numeric($CONFIG_MEMBER['delay_unactiv_max']) : '';
	$config_member['force_theme'] = isset($CONFIG_MEMBER['force_theme']) ? numeric($CONFIG_MEMBER['force_theme']) : 0; //D�sactiv� par d�faut.
	$config_member['activ_up_avatar'] = isset($CONFIG_MEMBER['activ_up_avatar']) ? numeric($CONFIG_MEMBER['activ_up_avatar']) : 0; //D�sactiv� par d�faut.
	$config_member['width_max'] = isset($CONFIG_MEMBER['width_max']) ? numeric($CONFIG_MEMBER['width_max']) : 120;
	$config_member['height_max'] = isset($CONFIG_MEMBER['height_max']) ? numeric($CONFIG_MEMBER['height_max']) : 120;
	$config_member['weight_max'] = isset($CONFIG_MEMBER['weight_max']) ? numeric($CONFIG_MEMBER['weight_max']) : 20;
	$config_member['activ_avatar'] = isset($CONFIG_MEMBER['activ_avatar']) ? numeric($CONFIG_MEMBER['activ_avatar']) : 0;
	$config_member['avatar_url'] = isset($CONFIG_MEMBER['avatar_url']) ? $CONFIG_MEMBER['avatar_url'] : 0;
	$config_member['msg_mbr'] = isset($CONFIG_MEMBER['msg_mbr']) ? $CONFIG_MEMBER['msg_mbr'] : '';
	
	$config_member['msg_register'] = !empty($_POST['contents']) ? stripslashes(parse($_POST['contents'])) : '';
	
	$sql->query_inject("UPDATE ".PREFIX."configs SET value = '" . addslashes(serialize($config_member)) . "' WHERE name = 'member'", __LINE__, __FILE__); //MAJ	
	
	###### R�g�n�ration du cache $CONFIG_MEMBER #######
	$cache->generate_file('member');
		
	header('location:' . HOST . SCRIPT); 	
	exit;
}
else
{			
	$template->set_filenames(array(
		'admin_terms' => '../templates/' . $CONFIG['theme'] . '/admin/admin_terms.tpl'
	));
	
	$template->assign_vars(array(
		'L_TERMS' => $LANG['register_terms'],
		'L_REQUIRE_TEXT' => $LANG['require_text'],
	));
	
	$template->assign_block_vars('register', array(
	));
			
	$msg_register = $sql->query("SELECT value FROM ".PREFIX."configs WHERE name = 'member'", __LINE__, __FILE__); //Message � l'inscription.
	
	$template->assign_vars(array(
		'CONTENTS' => unparse($CONFIG_MEMBER['msg_register']),
		'L_TERMS' => $LANG['register_terms'],
		'L_EXPLAIN_TERMS' => $LANG['explain_terms'],
		'L_CONTENTS' => $LANG['contents'],
		'L_UPDATE' => $LANG['update'],
		'L_PREVIEW' => $LANG['preview'],
		'L_RESET' => $LANG['reset']
	));		
	
	include_once('../includes/bbcode.php');
	$template->assign_var_from_handle('BBCODE', 'bbcode');
	
	$template->pparse('admin_terms'); 
}

include_once('../includes/admin_footer.php');

?>